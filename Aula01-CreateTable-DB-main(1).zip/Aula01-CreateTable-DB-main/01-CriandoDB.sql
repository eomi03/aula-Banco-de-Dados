CREATE DATABASE teste; 

SHOW DATABASES; 

USE teste; 

DROP DATABASE teste; 

CREATE DATABASE aula1;
    character set utf8mb4
    collate utf8mb4_unicode_ci;

SHOW DATABASES; 

USE aula1;





